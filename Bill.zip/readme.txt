﻿要求：密码为长度10个字符，账单总数量在小于10位数

实现思路：


class Bill记录单个账单

class BillStorage // 抽象存储层



在代码中引入 BillStorage 这一层作为 “中介”，主要是为了实现代码的解耦、提高可扩展性和可维护性
1. 实现代码解耦
将业务逻辑和数据存储分离：BillManagementSystem 类负责账单管理的业务逻辑，如添加账单、显示账单和查找账单等操作。而 BillStorage 类负责账单数据的存储和检索。通过将存储逻辑封装在 BillStorage 中，BillManagementSystem 不需要关心数据是如何具体存储的，只需要调用 BillStorage 提供的接口来完成相应的操作。这样，当存储方式发生变化时，BillManagementSystem 的业务逻辑代码不需要修改。
在当前代码中，BillManagementSystem 类的 addBill 方法只是简单地调用 storage->addBill(bill)，而不关心 storage 具体是如何实现 addBill 功能的。如果后续需要将存储方式从使用 std::vector 改为使用 SQL 数据库，只需要修改 BillStorage 的具体实现类，而 BillManagementSystem 类的代码不需要改动。
2. 提高可扩展性
方便切换存储方式：由于 BillStorage 是一个抽象基类，它定义了一组纯虚函数，这些函数构成了存储账单数据的通用接口。通过继承 BillStorage 类，可以实现不同的存储策略，如 VectorBillStorage 使用 std::vector 来存储账单，未来可以轻松添加新的存储实现，如 SQLBillStorage 用于与 SQL 数据库对接。
示例：如果要实现一个基于 SQL 数据库的存储方式，只需要创建一个新的类 SQLBillStorage 继承自 BillStorage，并实现 addBill、getAllBills 和 findBillsByDate 等纯虚函数，然后在使用时将 BillManagementSystem 类的构造函数参数替换为 SQLBillStorage 对象即可。
cpp
class SQLBillStorage : public BillStorage {
public:
    void addBill(const Bill& bill) override {
        // 实现将账单数据插入 SQL 数据库的逻辑
    }

    std::vector<Bill> getAllBills() const override {
        // 实现从 SQL 数据库中获取所有账单的逻辑
        return {};
    }

    std::vector<Bill> findBillsByDate(const std::string& date) const override {
        // 实现根据日期从 SQL 数据库中查找账单的逻辑
        return {};
    }
};


功能：
通过日期查找
支出种类查找
通过花销金额查找，如：20.82，2*.**






用户文档
用户手册：向用户介绍如何使用项目系统，包括系统的功能介绍、操作流程、常见问题解答等。
安装部署手册：提供项目的安装部署步骤、环境要求、配置说明等，方便用户进行系统的安装和部署。
项目文档的格式
文档格式
Word 文档：使用 Microsoft Word 或 WPS 文字等软件进行编写，具有丰富的排版功能，便于编辑和修改，适合撰写各种类型的项目文档。
Markdown 文档：以纯文本形式编写，通过简单的标记语法来实现文本的格式排版，具有轻量级、易读易写、跨平台等优点，常用于技术文档、README 文件等的编写。
PDF 文档：将编写好的文档转换为 PDF 格式，具有格式固定、不易被篡改、可跨平台阅读等优点，适合用于最终的文档交付。
图表格式
流程图：可以使用 Visio、ProcessOn 等工具绘制，用于描述业务流程、系统流程等。
用例图、类图等 UML 图：使用 StarUML、PlantUML 等工具绘制，用于描述系统的功能需求、设计结构等。
项目开发其他工作
代码开发：按照设计文档和代码规范，使用选定的技术框架和开发工具进行项目的编码实现。
项目测试：按照测试计划和测试用例，对项目进行功能测试、性能测试、安全测试等，确保项目的质量。
项目部署：将项目部署到生产环境中，确保项目能够正常运行，并提供相应的运维支持。
项目验收：与项目需求方或客户进行项目的验收工作，确保项目满足需求并通过验收。
项目维护：在项目上线后，对项目进行维护和优化，及时解决用户反馈的问题，对系统进行功能升级和性能优化等。
