//#pragma once
//#include <iostream>
//#include <chrono>
//#include <ctime>
//#include <stdexcept>
//
//class DateTime {
//private:
//    std::chrono::system_clock::time_point timePoint;
//
//    // �� std::chrono::system_clock::time_point ת��Ϊ std::tm
//    std::tm toTm(const std::chrono::system_clock::time_point& tp) const {
//        std::time_t tt = std::chrono::system_clock::to_time_t(tp);
//        return *std::localtime(&tt);
//    }
//
//    // �� std::tm ת��Ϊ std::chrono::system_clock::time_point
//    std::chrono::system_clock::time_point fromTm(const std::tm& tm) const {
//        std::time_t tt = std::mktime(const_cast<std::tm*>(&tm));
//        return std::chrono::system_clock::from_time_t(tt);
//    }
//
//public:
//    // ���캯����Ĭ�ϳ�ʼ��Ϊ��ǰʱ��
//    DateTime() : timePoint(std::chrono::system_clock::now()) {}
//
//    // ����Сʱ
//    void setHour(int hour) {
//        if (hour < 0 || hour > 23) {
//            throw std::invalid_argument("Hour must be in the range [0, 23].");
//        }
//        std::tm tm = toTm(timePoint);
//        tm.tm_hour = hour;
//        timePoint = fromTm(tm);
//    }
//
//    // ���÷���
//    void setMinute(int minute) {
//        if (minute < 0 || minute > 59) {
//            throw std::invalid_argument("Minute must be in the range [0, 59].");
//        }
//        std::tm tm = toTm(timePoint);
//        tm.tm_min = minute;
//        timePoint = fromTm(tm);
//    }
//
//    // �������
//    void setYear(int year) {
//        if (year < 1900) {
//            throw std::invalid_argument("Year must be at least 1900.");
//        }
//        std::tm tm = toTm(timePoint);
//        tm.tm_year = year - 1900; // std::tm ����ݴ� 1900 ��ʼ����
//        timePoint = fromTm(tm);
//    }
//
//    // �����·�
//    void setMonth(int month) {
//        if (month < 1 || month > 12) {
//            throw std::invalid_argument("Month must be in the range [1, 12].");
//        }
//        std::tm tm = toTm(timePoint);
//        tm.tm_mon = month - 1; // std::tm ���·ݴ� 0 ��ʼ����
//        timePoint = fromTm(tm);
//    }
//
//    // ��������
//    void setDay(int day) {
//        if (day < 1 || day > 31) {
//            throw std::invalid_argument("Day must be in the range [1, 31].");
//        }
//        std::tm tm = toTm(timePoint);
//        tm.tm_mday = day;
//        timePoint = fromTm(tm);
//    }
//
//    // ��ȡ��ǰ�洢��ʱ���
//    std::chrono::system_clock::time_point getTimePoint() const {
//        return timePoint;
//    }
//};
//
//// �������������ڴ�ӡʱ����Ӧ�����ں�ʱ��
//void printDateTime(const std::chrono::system_clock::time_point& tp) {
//    std::time_t tt = std::chrono::system_clock::to_time_t(tp);
//    std::cout << std::ctime(&tt);
//}
//
//int main() {
//    DateTime dt;
//    std::cout << "Initial time: ";
//    printDateTime(dt.getTimePoint());
//
//    try {
//        dt.setYear(2026);
//        dt.setMonth(12);
//        dt.setDay(25);
//        dt.setHour(14);
//        dt.setMinute(30);
//
//        std::cout << "Modified time: ";
//        printDateTime(dt.getTimePoint());
//
//        // ���Բ��Ϸ�����
//        dt.setHour(25);
//    }
//    catch (const std::invalid_argument& e) {
//        std::cerr << "Error: " << e.what() << std::endl;
//    }
//
//    return 0;
//}